// quiz app

const questions = [
    {
        question: "What does HTML stands for ?",
        options: [
                "A. HighText Machine Language",
                "B. HyperText and links Markup Language",
                "C. HyperText Markup Language",
                "D. None of these"
        ],
        correctAnswer: 2
    },
    {
        question: "What does CSS stands for?",
        options: [
            "A. Cascade style sheets",
            "B. Color and style sheets",
            "C. Cascading style sheets",
            "D. None of the above"
        ],
        correctAnswer: 2
    },
    {
        question: "What is the full form of SQL?",
        options: [
            "A. Structured Query List",
            "B. Structure Query Language",
            "C. Sample Query Language",
            "D. None of these."
        ],
        correctAnswer: 1
    },
    {
        question: "What is the full form of DBMS?",
        options: [
            "A. Data of Binary Management System",
            "B. Database Management System",
            "C. Database Management Service",
            "D. Data Backup Management System"
        ],
        correctAnswer: 1
    },
    {
        question: "What does PHP stands for?",
        options: [
            "A. Hypertext Preprocessor",
            "B. Pretext Hypertext Preprocesso",
            "C. None of the above",
            "D. Personal Home Processor"
        ],
        correctAnswer: 0
    }
];

let currentQuestionIndex = 0;
let score = 0;

const questionContainer = document.getElementById('question-container');
const nextButton = document.getElementById('next-btn');
const feedbackContainer = document.getElementById('feedback-container');
const scoreContainer = document.getElementById('score-container');

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionContainer.innerHTML = `
        <h2 class="heading">${currentQuestion.question}</h2>
        <ul class="option-list">
            ${currentQuestion.options.map((option, index) => `<li><input type="radio" name="answer" value="${index}">${option}</li>`).join('')}
        </ul>
    `;
}

function showFeedback(isCorrect) {
    feedbackContainer.textContent = isCorrect ? "Correct!" : "Incorrect!";
    feedbackContainer.style.color = isCorrect ? "green" : "red";
}

function checkAnswer() {
    const selectedAnswer = document.querySelector('input[name="answer"]:checked');
    if (!selectedAnswer) {
        alert("Please select an answer!");
        return;
    }
    const selectedOptionIndex = parseInt(selectedAnswer.value);
    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = selectedOptionIndex === currentQuestion.correctAnswer;
    showFeedback(isCorrect);
    if (isCorrect) {
        score++;
    }
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
        feedbackContainer.textContent = '';
    } else {
        showScore();
    }
}

function showScore() {
    questionContainer.innerHTML = "";
    nextButton.style.display = "none";
    scoreContainer.textContent = `Your Score: ${score} out of ${questions.length}`;
    scoreContainer.style.display = "block";
}

nextButton.addEventListener('click', function() {
    checkAnswer();
    nextQuestion();
});

showQuestion();
